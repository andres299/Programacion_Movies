package com.esliceu.demoMovies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMoviesApplicationTests {

	@Test
	void contextLoads() {
	}

}
