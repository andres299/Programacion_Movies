package com.esliceu.demoMovies.Entities;

import jakarta.persistence.*;

@Entity
@Table(
        name = "movie_company",
        uniqueConstraints =
        @UniqueConstraint(columnNames = {"movie_id", "company_id"})
)
public class Movie_Company {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "movie_id")
    private Movie movie;

    @ManyToOne
    @JoinColumn(name = "company_id")
    private Production_Company company;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Production_Company getCompany() {
        return company;
    }

    public void setCompany(Production_Company company) {
        this.company = company;
    }
}
