package com.esliceu.demoMovies.Entities;

import jakarta.persistence.*;
import org.springframework.data.annotation.Id;

@Entity
@Table(
        name = "movie_keywords",
        uniqueConstraints =
        @UniqueConstraint(columnNames = {"movie_id", "keyword_id"})
)
public class Movie_Keywords {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "movie_id", referencedColumnName = "movie_id")
    private Movie movie;

    @ManyToOne
    @JoinColumn(name = "keyword_id", referencedColumnName = "keyword_id")
    private Keyword keyword;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Keyword getKeyword() {
        return keyword;
    }

    public void setKeyword(Keyword keyword) {
        this.keyword = keyword;
    }
}
