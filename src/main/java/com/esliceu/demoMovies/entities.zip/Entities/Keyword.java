package com.esliceu.demoMovies.Entities;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Keyword {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long keyword_id;

    @OneToMany(mappedBy = "keyword")
    private List<Movie_Keywords> movieKeywordsList;
    private String keyword_name;

    public Long getKeyword_id() {
        return keyword_id;
    }

    public void setKeyword_id(Long keyword_id) {
        this.keyword_id = keyword_id;
    }

    public List<Movie_Keywords> getMovieKeywordsList() {
        return movieKeywordsList;
    }

    public void setMovieKeywordsList(List<Movie_Keywords> movieKeywordsList) {
        this.movieKeywordsList = movieKeywordsList;
    }

    public String getKeyword_name() {
        return keyword_name;
    }

    public void setKeyword_name(String keyword_name) {
        this.keyword_name = keyword_name;
    }
}
